//
//  Weather_appApp.swift
//  Weather_app
//
//  Created by António Pedro Ramos Velez on 14/04/2023.
//

import SwiftUI

@main
struct Weather_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
